package Quantra_Assignment;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;
import Base.BaseClass;
import Pages.CartPage;
import Pages.CourseDetailsPage;
import Pages.CoursesPage;
import Pages.DashboardPage;
import Pages.LoginPage;

public class QuantraE2EBusinessFlowTest extends BaseClass {

	String URL 					= "https://quantra.quantinsti.com/";

	@Test
	private void processTestCase() {
		// Open URL
		driver.get(URL);
		
		//Creating login page object and calling its method to perform login
		LoginPage loginPageObj = new LoginPage(driver, wait);
		
		DashboardPage dashboardPageObj = loginPageObj.processLoginWithValidCredentials();
		
		CoursesPage coursesPageObj = dashboardPageObj.clickOnBrowseCourses();
		
		CourseDetailsPage courseDetailsPageObj = coursesPageObj.clickOnSpecificCourse("Sentiment Analysis in Trading");
		
		System.out.println("Course Name is: "+courseDetailsPageObj.getCourseName()+"\nCourse Price is: "+courseDetailsPageObj.getCoursePrice());
		
		CartPage cartPageObj = courseDetailsPageObj.clickOnEnrollNowBtn();
				
		System.out.println("List of courses present on cart page:");
		for(String name: cartPageObj.getCourseTitlesInCart()) {
			System.out.println(name);
		}
		
		
		//Displaying Base Amount & Amount Payable
		System.out.println("Base Amount of the Course is: " + cartPageObj.getBaseAmount());
		System.out.println("Amount Payable for the Course is: " + cartPageObj.getAmountPayable());
		
		cartPageObj.clickOnViewDetailsLink();
		
		cartPageObj.clickOnremoveLink();
		
		System.out.println("Success Message after removing course from Cart: " + cartPageObj.getToastMsgAfterRemoval());
		
		//Click on Apply Coupon Enter invalid value and print error message;
		System.out.println("Error Message on wrong coupon entered: " + cartPageObj.clickOnApplyCoupon());
		
		cartPageObj.clickOnCloseBtn();
		
		//cartPageObj.signOut();
			
	}
}
