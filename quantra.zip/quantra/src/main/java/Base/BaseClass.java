package Base;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseClass {

	protected WebDriver driver;
	protected WebDriverWait wait;

	@BeforeTest
	protected void startBrowser() {

		System.setProperty("webdriver.chrome.driver",
				"src\\\\main\\\\resources\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 10);
	}

	@AfterTest
	protected void stopBrowser() {
		driver.close();
	}

}
