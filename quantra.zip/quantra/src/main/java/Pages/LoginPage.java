package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	
	WebDriver driver;
	WebDriverWait wait;
	
	String emailData			= "ghavleswati@gmail.com";
	String passwordData			= "Sarves@143";
	By subscriptionPopupBox 	= By.xpath("//div[@class='web-push-container']");
	By remindMeLaterBtn 		= By.xpath("//button[text()='Remind me later']");
	By loginBtnOnHomePage 		= By.xpath("//button//span[text()='Login']");
	By emailInputBox 			= By.xpath("//input[@name='email']");
	By passwordInputBox 		= By.xpath("//input[@name='password']");
	By loginBtnOnLoginPage 		= By.xpath("//button[@type='submit']");
	
	public LoginPage(WebDriver driver, WebDriverWait wait){
		this.driver = driver;
		this.wait = wait;
	}
	
	public DashboardPage processLoginWithValidCredentials() {
		
		// Check and cancel Subscription pop-up if exist.
				if (isElementPresent(subscriptionPopupBox) > 0) {
					findElement(remindMeLaterBtn).click();
				}

		// Click on login button
		findElement(loginBtnOnHomePage).click();

		// wait for login page elements and enter data.
		waitForAnElementToBePresent(emailInputBox).sendKeys(emailData);
		waitForAnElementToBePresent(passwordInputBox).sendKeys(passwordData);
		waitForAnElementToBePresent(loginBtnOnLoginPage).click();
		
		return new DashboardPage(driver, wait);
	}
	
	//Supporting Methods of this class
	private WebElement findElement(By loc) {
		return driver.findElement(loc);
	}

	private int isElementPresent(By loc) {
		return driver.findElements(loc).size();
	}

	private WebElement waitForAnElementToBePresent(By loc) {
		return wait.until(ExpectedConditions.presenceOfElementLocated(loc));
	}

}
