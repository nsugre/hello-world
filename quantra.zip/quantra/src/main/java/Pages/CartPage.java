package Pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {
	
	WebDriver driver;
	WebDriverWait wait;
	By courseNameTitle 		= By.xpath("//div[@class='cart-item']//h5");
	By cartCount			= By.xpath("//li//span[@class='cart-count']");
	By baseAmount			= By.xpath("//div[text()='Base Amount']/following-sibling::div");
	By amountPayable		= By.xpath("//h5[text()='Amount Payable']/../following-sibling::div//span");
	By viewDetailsLink		= By.xpath("//a[text()='View Details']");
	By removeLink			= By.xpath("//a[text()='Remove']");
	By toastMsgAfterRemove	= By.xpath("//div[@class='toasted toasted-primary info']");
	By applyCouponBtn		= By.xpath("//span[text()='Apply Coupon']");
	By coupnInputBox		= By.xpath("//form[@class='coupon-form']//input");
	By wrongCouponMsg		= By.xpath("//span[text()='Oops! This coupon is no longer valid.']");
	By couponModalCloseBtn  = By.xpath("//div[@id='coupon-modal']//button[@class='close']");
	By profileIcon			= By.xpath("//div[@class='profile-pic-initials']");
	By signOutLink			= By.xpath("(//a[text()='Logout'])[2]");
	
	public CartPage(WebDriver driver, WebDriverWait wait){
		this.driver = driver;
		this.wait   = wait;
	}
	
	//This method will get and return list of courses title on this page.
	public List<String> getCourseTitlesInCart() {
		List<String> courseNamesStr = new ArrayList<String>();
		waitForAnElementToBePresent(courseNameTitle);
		List<WebElement> courseNamesEle = findElements(courseNameTitle);
		for(WebElement ele : courseNamesEle ) {
			courseNamesStr.add(ele.getText());
		}
		return courseNamesStr;
	}
	
	//This method will get and return count of courses on this page.
	public int getCoursesCountInCart() {
		int courseCounter;
		courseCounter = findElements(courseNameTitle).size();
		return courseCounter;
	}
	
	//This method will get and return cart count on this page.
	public String getCartCount() {
		
		return findElement(cartCount).getText();
		 
	}
	
	//This method will get and return Base Amount on this page.
	public String getBaseAmount() {
		
		return findElement(baseAmount).getText();
		 
	}
	
	//This method will get and return Amount payable info on this page.
	public String getAmountPayable() {
		
		return findElement(amountPayable).getText();
		 
	}
	
	//This method will click on View Details link of first course in the list.
	public void clickOnViewDetailsLink() {
		
		waitForAnElementToBeClickable(viewDetailsLink).click();
		
		//this code will switch to new tab close it and switch back to cart tab.
		String parent = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for(String handle: handles) {
			if(!parent.equals(handle)) {
				driver.switchTo().window(handle);
				driver.close();
				driver.switchTo().window(parent);
			}
		} 
	}
	
	//This method will get and return toast message after removing course from screen
	public String getToastMsgAfterRemoval() {
		
		return waitForAnElementToBePresent(toastMsgAfterRemove).getText();
		
	}
	
	//This method will click on View Details link of first course in the list.
	public void clickOnremoveLink() {
		
		waitForAnElementToBeClickable(removeLink).click();
		
	}
	
	//This method will click on Apply Coupon Button and enter wrong value and get the error message.
	public String clickOnApplyCoupon() {
		
		WebElement element = driver.findElement(applyCouponBtn);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		waitForAnElementToBePresent(coupnInputBox).sendKeys("ABC");
		WebElement applyBtn = driver.findElement(By.xpath("//form[@class='coupon-form']//button"));
		executor.executeScript("arguments[0].click();", applyBtn);
		WebElement ele = waitForAnElementToBePresent(wrongCouponMsg);
		String msg = ele.getText();
		return msg;
	}
	
	public void signOut() {
		
		WebElement profile = waitForAnElementToBeClickable(profileIcon);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", profile);
		waitForAnElementToBeClickable(signOutLink).click();
		
	}
	
	//This method will close the coupon modal.
	public void clickOnCloseBtn() {
		findElement(couponModalCloseBtn).click();
	}
	
	//Supporting Methods of this class
	private List<WebElement> findElements(By loc) {
		return driver.findElements(loc);
	}
	
	private WebElement findElement(By loc) {
		return driver.findElement(loc);
	}
	
	private WebElement waitForAnElementToBePresent(By loc) {
		return wait.until(ExpectedConditions.presenceOfElementLocated(loc));
	}
	
	private WebElement waitForAnElementToBeClickable(By loc) {
		return wait.until(ExpectedConditions.elementToBeClickable(loc));
	}
	
	
}
