package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CourseDetailsPage {
	
	WebDriver driver;
	WebDriverWait wait;
	By courseName					= By.xpath("//h1");
	By subscriptionPopupBox 	= By.xpath("//div[@class='web-push-container']");
	By remindMeLaterBtn 		= By.xpath("//button[text()='Remind me later']");
	By coursePrice					= By.xpath("(//div[contains(@class,'price-data-unit')]//span)[last()]");
	By enrollNowBtn					= By.xpath("//div[@id='courseDetailMenu']//span[contains(text(),'Enroll Now')]");
	
	
	public CourseDetailsPage(WebDriver driver, WebDriverWait wait){
		this.driver = driver;
		this.wait   = wait;
	}
	
	//This method will return course Name and CoursePrice.
	public String getCourseName() {	
		
		return waitForAnElementToBePresent(courseName).getText();
		
	}
	
	//This method will return course Name and CoursePrice.
	public String getCoursePrice() {	
		
		return waitForAnElementToBePresent(coursePrice).getText();
		
	}
	
	//This method will click on Enroll Now button
	public CartPage clickOnEnrollNowBtn() {	
		
		//waitForAnElementToBeClickable(enrollNowBtn).click();
		
		// Check and cancel Subscription pop-up if exist.
		if (isElementPresent(subscriptionPopupBox) > 0) {
			findElement(remindMeLaterBtn).click();
		}
		
		WebElement element = driver.findElement(enrollNowBtn);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		
		return new CartPage(driver, wait);
		
	}
	
	//Supporting Methods of this class
	private WebElement waitForAnElementToBePresent(By loc) {
		return wait.until(ExpectedConditions.presenceOfElementLocated(loc));
	}
	
	private WebElement findElement(By loc) {
		return driver.findElement(loc);
	}

	private int isElementPresent(By loc) {
		return driver.findElements(loc).size();
	}
	
	

}
