package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CoursesPage {
	
	WebDriver driver;
	WebDriverWait wait;
	
	public CoursesPage(WebDriver driver, WebDriverWait wait){
		this.driver = driver;
		this.wait   = wait;
	}
	
	//This method will take Course Name we want to select from Test Case
	public CourseDetailsPage clickOnSpecificCourse(String courseLinkStr) {
		
		//Construct a locator by string passed from test case
		//waitForAnElementToBeClickable(buildDynamicLocatorsForCourseLink(courseLinkStr)).click();
		WebElement element = driver.findElement(buildDynamicLocatorsForCourseLink(courseLinkStr));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
		return new CourseDetailsPage(driver, wait);
	}
	
	//Supporting Methods of this class
	private WebElement waitForAnElementToBeClickable(By loc) {
		return wait.until(ExpectedConditions.elementToBeClickable(loc));
	}
	
	private By buildDynamicLocatorsForCourseLink(String str) {
		String lnkStr = "//a[@data-title='"+str+"']";
		By courseLink = By.xpath(lnkStr);
		return courseLink;
	}
	
	
	

}
