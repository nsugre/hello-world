package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DashboardPage {
	
	WebDriver driver;
	WebDriverWait wait;
	By browseCoursesLink			= By.xpath("//a[contains(text(),'Browse Courses')]");
	

	public DashboardPage(WebDriver driver, WebDriverWait wait){
		this.driver = driver;
		this.wait = wait;
	}
	
	public CoursesPage clickOnBrowseCourses() {	
		
		// Check if we are on correct page
		waitForAnElementToBeClickable(browseCoursesLink).click();
		new Actions(driver).moveToElement(driver.findElement(By.xpath("//input[@placeholder='Search a course']"))).perform();
		return new CoursesPage(driver, wait);
		
	}
	
	//Supporting Methods of this class
	private WebElement waitForAnElementToBeClickable(By loc) {
		return wait.until(ExpectedConditions.elementToBeClickable(loc));
	}

}
